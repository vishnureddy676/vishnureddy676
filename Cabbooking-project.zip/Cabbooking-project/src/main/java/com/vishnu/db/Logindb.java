package com.vishnu.db;

import java.util.List;

import com.vishnu.dto.Extract;

public interface Logindb {
	
	public void Insert(Object[]  vis);
	public List<Extract>  Login(String s1, String s2);

}
