package com.vishnu.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import com.vishnu.db.Logindatabase;
import com.vishnu.db.Logindb;
import com.vishnu.dto.Extract;
import com.vishnu.dto.LoginDTO;
import com.vishnu.dto.User;

@Controller
public class Logincontroller {
	@GetMapping("/")
	public String showstudentList() {
		
		return "home-page";
		
	}
	
	@RequestMapping("/sucess")
	public String regstudentList(LoginDTO loginDTO) {
		
		Object[] vis= {loginDTO.getUname(),
		loginDTO.getPsw(),loginDTO.getCountry(),loginDTO.getMobile()};
		
		
		Logindatabase logindatabase =new Logindatabase();
		logindatabase.Insert(vis);
		
		
		
		return "sucess-page";
	}
	@RequestMapping("/link")
	public String showpage() {
		return "reg-page";
	}
	
	@RequestMapping("/login")
	public String login() {
		return "login-page";
	}
	
	@RequestMapping("/onlogin")
	public String loginsubmission(User user) {
		
		String uname= user.getUname();
		String password= user.getPsw();
		
		Logindatabase logindatabase =new Logindatabase();
		
		List<Extract> extracts= logindatabase.Login(uname,password);
		
		for(Extract temp:extracts) {
			System.out.println(temp);
		}
	
		
		
		
		return "sucess-page";
	}
	
	
	
	

}
